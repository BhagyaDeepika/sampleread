# -*- coding: utf-8 -*-
from __future__ import print_function, unicode_literals, division, absolute_import


#DEFAULT_BATCH_SIZE=1000


DEFAULT_BASE_URL_FOR_TEXT = 'https://api.github.com'





